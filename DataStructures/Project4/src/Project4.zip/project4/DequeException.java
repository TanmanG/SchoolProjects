/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project4;

/**
 *
 * @author Tanner Good
 */
public class DequeException extends RuntimeException {
    public DequeException(String error){
        super(error);
    }
}
